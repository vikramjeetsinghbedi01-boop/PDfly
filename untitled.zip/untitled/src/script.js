const dropArea = document.getElementById("drop-area");
const fileInput = document.getElementById("fileElem");
const preview = document.getElementById("preview");
const downloadBtn = document.getElementById("downloadBtn");
const fileCountText = document.getElementById("fileCount");
const pdfNameInput = document.getElementById("pdfName");

let selectedFiles = [];

dropArea.addEventListener("click", () => fileInput.click());

fileInput.addEventListener("change", (e) => {
  handleFiles(e.target.files);
});

function handleFiles(files) {
  selectedFiles = [...files];
  preview.innerHTML = "";

  selectedFiles.forEach((file) => {
    const reader = new FileReader();
    reader.onload = function (e) {
      const img = document.createElement("img");
      img.src = e.target.result;
      img.classList.add("preview-img");
      preview.appendChild(img);
    };
    reader.readAsDataURL(file);
  });

  fileCountText.textContent = `${selectedFiles.length} image(s) selected`;
}

downloadBtn.addEventListener("click", async () => {
  if (selectedFiles.length === 0) {
    alert("Select images first.");
    return;
  }

  let pdfName = pdfNameInput.value.trim();
  if (pdfName === "") pdfName = "PDFly-Document";

  downloadBtn.disabled = true;
  downloadBtn.textContent = "Generating PDF...";

  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF();

  for (let i = 0; i < selectedFiles.length; i++) {
    const imgData = await fileToDataURL(selectedFiles[i]);
    const img = new Image();
    img.src = imgData;

    await new Promise((resolve) => {
      img.onload = function () {
        const width = pdf.internal.pageSize.getWidth();
        const height = (img.height * width) / img.width;
        if (i !== 0) pdf.addPage();
        pdf.addImage(imgData, "JPEG", 0, 0, width, height);
        resolve();
      };
    });
  }

  pdf.save(`${pdfName}.pdf`);

  downloadBtn.disabled = false;
  downloadBtn.textContent = "Download PDF";
});

function fileToDataURL(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target.result);
    reader.readAsDataURL(file);
  });
}

/* PAGE SWITCHING (SAFE VERSION) */

function showHome() { hideAll(); document.getElementById("homeSection").classList.remove("hidden"); }
function showAbout() { hideAll(); document.getElementById("aboutSection").classList.remove("hidden"); }
function showFAQ() { hideAll(); document.getElementById("faqSection").classList.remove("hidden"); }
function showPrivacy() { hideAll(); document.getElementById("privacySection").classList.remove("hidden"); }
function showContact() { hideAll(); document.getElementById("contactSection").classList.remove("hidden"); }
function showTerms() { hideAll(); document.getElementById("termsSection").classList.remove("hidden"); }

function hideAll() {
  const sections = [
    "homeSection",
    "aboutSection",
    "faqSection",
    "privacySection",
    "contactSection",
    "termsSection"
  ];

  sections.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.add("hidden");
  });
}

/* ABOUT CONTENT */
document.getElementById("aboutContent").innerHTML = `
<h2>About PDFly</h2>
<p>PDFly was founded by <strong>(your name here)</strong> to create clean and simple digital tools.</p>
<p>The goal is to provide fast, secure, and distraction-free PDF utilities directly in your browser.</p>
<p>All files are processed locally, ensuring privacy and security.</p>
<p>PDFly continues evolving with modern design and performance in mind.</p>
`;
